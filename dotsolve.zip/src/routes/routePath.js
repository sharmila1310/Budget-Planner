const routePath = {
  root: "/",
  login: "/login",
  about: "/about",
  contact: "/contact",
};

export default routePath;
